import sqlite3
import pandas as pd
import matplotlib as plt
import os
#os.chdir("/Users/haim/OneDrive - University of Connecticut/Documents/Research/MG")
abspath = os.path.dirname(__file__)
os.chdir(abspath)
with open("localdirdata") as f:
    data = f.readlines()
datdir = data[0].rstrip()
con = sqlite3.connect(datdir + "/mg")
cur = con.cursor()
res = cur.execute('SELECT COUNT(*) FROM PERSONS')
totalpeople = res.fetchall()
print('Total number of people: ' + str(totalpeople[0][0]))

res = cur.execute('SELECT COUNT(*) FROM DEGREES')
totaldegrees = res.fetchall()
print('Total number of degrees: ' + str(totaldegrees[0][0]))

res = cur.execute('SELECT COUNT(*) FROM STUDENTS')
totalpairs = res.fetchall()
print('Total number of advisor/student pairs: ' + str(totalpairs[0][0]))

res = cur.execute('SELECT COUNT(*) FROM DEGREES where DEGMSC = "Unknown"')
totalnamsc = res.fetchall()
print('Total number missing MSC: ' + str(totalnamsc[0][0]))

res = cur.execute('SELECT COUNT(*) FROM DEGREES where TITLE = "Unknown"')
totalnattl = res.fetchall()
print('Total number missing titles: ' + str(totalnattl[0][0]))

res = cur.execute('SELECT GIVENFIELD,COUNT(*) FROM FIELDS GROUP BY GIVENFIELD ORDER BY COUNT(*) DESC')
countbyfield = res.fetchall()
fld = pd.DataFrame((countbyfield))
print(fld.to_latex())

res = cur.execute('SELECT COUNTRY,COUNT(*) FROM DEGREES GROUP BY COUNTRY ORDER BY COUNT(*) DESC LIMIT 20')
countbycountry = res.fetchall()
ctry = pd.DataFrame((countbycountry))
print(ctry.to_latex())

res = cur.execute('SELECT DEGYEAR,COUNT(*) FROM DEGREES GROUP BY DEGYEAR ORDER BY DEGYEAR')
countbyyear = res.fetchall()
year = pd.DataFrame((countbyyear))

a = pd.to_numeric(year[0], errors='coerce')
np.where(a.isna() == False)[0]

cntyear = year.iloc[np.where(a.isna() == False)[0]]
plt.pyplot.scatter(cntyear[0], cntyear[1])
plt.pyplot.show()

plt.pyplot.scatter(cntyear[0], np.log10(cntyear[1]))
plt.pyplot.show()

res = cur.execute('select count(*) from fields where givenfield != INFERREDFIELD')
imputed = res.fetchall()
print('Total number of imputed fields (first stage): ' + str(imputed[0][0]))


