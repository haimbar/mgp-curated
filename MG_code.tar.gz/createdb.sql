CREATE TABLE MSC
         (CODE  INTEGER     NOT NULL,
          NAME  CHAR(100)   NOT NULL );

CREATE TABLE PERSONS
         (MGID INTEGER PRIMARY KEY,
         LNAME  CHAR(30)     NOT NULL,
         FNAME  CHAR(30)     NOT NULL,
         ONAME  CHAR(30) );

CREATE TABLE DEGREES
         (DEGMGID INTEGER REFERENCES PERSONS(MGID),
         DEGTYPE  CHAR(30)     NOT NULL,
         DEGMSC   INTEGER      REFERENCES MSC(CODE),
         DEGYEAR  INTEGER      NOT NULL,
         SCHOOL   CHAR(60)     NOT NULL,
         COUNTRY  CHAR(30)     NOT NULL,
         TITLE    CHAR(300)    NOT NULL,
         LANGUAGE CHAR(30) );

CREATE TABLE STUDENTS
         (ADVISOR INTEGER REFERENCES PERSONS(MGID),
          STUDENT INTEGER REFERENCES PERSONS(MGID) );

CREATE TABLE FIELDS
    (MGID INTEGER REFERENCES PERSONS(MGID),
    GIVENFIELD CHAR(5) DEFAULT NA,
    INFERREDFIELD CHAR(5));

CREATE TABLE SCORES
    (MGID INTEGER REFERENCES PERSONS(MGID),
    METHOD CHAR(20) NOT NULL,
    MATH DECIMAL(1, 3), STAT DECIMAL(1, 3), CS DECIMAL(1, 3),
    PHYS DECIMAL(1, 3), ORE DECIMAL(1, 3),  ECON DECIMAL(1, 3), 
    BIOL DECIMAL(1, 3), OTHER DECIMAL(1, 3) );
    



.import msc MSC
.import persons.txt PERSONS
.import degrees.txt DEGREES
.import studuniq.txt STUDENTS

.import fieldsinferred2.txt FIELDS

# select * from persons where mgid in (select student from students where advisor=cast(219364 as text));

# fix some data problems:
UPDATE degrees SET degyear = 2018 WHERE degyear = 'Aug. 2018';
UPDATE degrees SET degyear = 2007 WHERE degyear = '200';
UPDATE degrees SET degyear = 1999 WHERE degyear = '199';
UPDATE degrees SET degyear = 2014 WHERE degyear = '43';

https://www.erdgo.com/e/new



.mode csv
.output ~/Desktop/mscs.csv
SELECT STUDENTS.STUDENT, STUDENTS.ADVISOR, DEGREES.DEGMSC, DEGREES.DEGYEAR 
FROM STUDENTS 
LEFT JOIN DEGREES ON STUDENTS.student = DEGREES.DEGMGID
WHERE DEGREES.DEGYEAR BETWEEN 1924 and 2025 ;
.output stdout